import { ChangeDetectionStrategy, Component, effect, inject, Injector, Input, OnInit } from '@angular/core';
import { PageBuilderBaseComponent } from '../page-builder-base-component';
import { FormsModule } from '@angular/forms';
import { SortPageListComponent } from '../sort-page-list/sort-page-list.component';
import { NgxIconComponent } from 'ngx-page-builder/icons';
import { ImportDialogComponent } from '../../dialogs/import-dialog/import-dialog.component';
import { ExportHtmlService } from '../../services/import-export/export-html.service';
import { HistoryService } from '../../services/history.service';
import { preparePageDataForSave } from '../../helper/prepare-page-builder-data';
import {
  LibConsts,
  PageItem,
  PagePreviewService,
  CustomToolbarButtons,
  LOCAL_STORAGE_SHOW_OUTLINE_KEY,
  DEFAULT_BREAKPOINTS,
  type Breakpoint,
} from 'ngx-page-builder/core';
import { PreviewDialogComponent } from '../../dialogs/preview-dialog/preview-dialog.component';
import { Notify } from 'ngx-kit/notify';
import { MSG } from 'ngx-kit/message';
import { NgxDialogService } from 'ngx-kit/dialog';
import { CssFileDialogComponent } from '../../dialogs/css-file-dialog/css-file-dialog.component';
@Component({
  selector: 'toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss'],
  standalone: true,
  imports: [FormsModule, NgxIconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ExportHtmlService],
})
export class ToolbarComponent extends PageBuilderBaseComponent implements OnInit {
  @Input() customToolbarButtons: CustomToolbarButtons[] = [];
  pageNumber: number = 1;
  enableHistory = LibConsts.enableHistory;
  toolbarConfig = LibConsts.toolbarConfig;

  breakPoints = DEFAULT_BREAKPOINTS;
  protected readonly exporter = inject(ExportHtmlService);
  protected readonly history = inject(HistoryService);
  protected readonly previewService = inject(PagePreviewService);
  protected readonly dialog = inject(NgxDialogService);

  constructor() {
    super();
    effect(() => {
      this.pageNumber = this.pb.currentPageIndex() + 1;
      this.chdRef.detectChanges();
    });
  }

  ngOnInit() {
    // console.log('LibConsts', LibConsts);
  }

  get canUndo(): boolean {
    return this.history.canUndo();
  }
  get canRedo(): boolean {
    return this.history.canRedo();
  }
  undo() {
    if (!this.pb.currentPage) {
      return;
    }
    let blocks = this.pb.currentPage.bodyItems;
    blocks = this.history.undo(blocks);
    this.pb.updatePage(blocks);
  }
  redo() {
    if (!this.pb.currentPage) {
      return;
    }
    let blocks = this.pb.currentPage.bodyItems;
    blocks = this.history.redo(blocks);
    this.pb.updatePage(blocks);
  }

  getHistory() {
    console.log(this.history.getHistory());
  }

  changePage() {
    this.pb
      .changePage(this.pageNumber)
      .then((index) => {
        this.pageNumber = index + 1;
      })
      .catch((er) => {
        this.pageNumber = this.pb.currentPageIndex() + 1;
      });
  }

  addPage() {
    this.pb.addPage().then((index) => {
      this.pageNumber = index + 1;
    });
  }

  removePage() {
    const c = confirm('Are you sure you want to remove this page?');
    if (c) {
      this.pb.removePage().then((index) => {
        this.pageNumber = index + 1;
      });
    }
  }
  nextPage() {
    this.pb
      .nextPage()
      .then((index) => {
        this.pageNumber = index + 1;
      })
      .catch(() => {});
  }
  previousPage() {
    this.pb
      .previousPage()
      .then((index) => {
        this.pageNumber = index + 1;
      })
      .catch(() => {});
  }

  onSave() {
    this.pb.save();
  }

  async onOpen() {
    await this.pb.open();
    console.log(this.pb.pageInfo, this.pb.pageInfo.pages.length);
    this.chdRef.detectChanges();
  }

  onNew() {
    MSG.question('Are you sure reset canvas?').afterClose.subscribe((r) => {
      if (r.isConfirmed) {
        this.pb.new();
      }
    });
  }

  toggleOutlines() {
    this.pb.showOutlines.update((u) => !u);
    localStorage.setItem(LOCAL_STORAGE_SHOW_OUTLINE_KEY, this.pb.showOutlines() + '');
  }
  deSelectBlock() {
    this.pb.deSelectBlock();
  }

  async print() {
    const data = await preparePageDataForSave(this.pb);
    await this.previewService.openPreview(data, 'Print');
  }
  async preview() {
    const data = await preparePageDataForSave(this.pb);
    this.dialog.open(PreviewDialogComponent, {
      data: {
        data,
        dynamicData: this.dynamicDataService.dynamicData,
        viewMode: this.viewMode,
      },
      maxWidth: '100%',
      minWidth: '95dvw',
      height: '95dvh',
      header: {
        showMaximizeButton: true,
        showCloseButton: true,
      },
      panelClass: 'ngx-page-builder',
    });
    // await this.previewService.openPreview(data, 'Preview');
  }

  previewPage() {
    this.doc?.open('/preview');
  }
  sortPages() {
    this.dialog.open(SortPageListComponent).afterClosed.subscribe((result) => {
      if (result) {
        this.pb.reloadCurrentPage();
      }
    });
  }

  openCssFileDialog() {
    this.dialog
      .open(CssFileDialogComponent, {
        data: {
          classes: {},
        },
        width: '80vw',
        maxWidth: '100%',
        header: {
          showMaximizeButton: true,
          showCloseButton: true,
        },
        panelClass: 'ngx-page-builder',
      })
      .afterClosed.subscribe((r) => {
        this.chdRef.detectChanges();
      });
  }

  async exportHtml() {
    const data = await preparePageDataForSave(this.pb);
    this.exporter.exportHtml(data);
  }
  importHtml() {
    const pageIndex = this.pb.currentPageIndex();
    if (pageIndex < 0) {
      Notify.error('Create page to import');
      return;
    }
    this.dialog
      .open(ImportDialogComponent, {
        width: '80%',
        minWidth: '80%',
        maxWidth: '100%',
        height: '95dvh',
        header: {
          showMaximizeButton: true,
          showCloseButton: true,
        },
        panelClass: 'ngx-page-builder',
      })
      .afterClosed.subscribe(async (r?: PageItem[]) => {
        if (r) {
          this.pb.pageInfo.pages[pageIndex].bodyItems.push(...r);
          r.map(async (item) => await this.pb.createBlockElement(true, item));
          this.chdRef.detectChanges();
        }
      });
  }

  changeResponive(b: Breakpoint) {
    this.pb.responsive.set(b);
  }
}
