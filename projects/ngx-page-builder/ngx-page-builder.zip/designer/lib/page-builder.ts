import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  Injector,
  input,
  Input,
  OnDestroy,
  OnInit,
  signal,
  viewChild,
  ViewEncapsulation,
} from '@angular/core';
import { ToolbarComponent } from './toolbar/toolbar.component';
import { PageBuilderBaseComponent } from './page-builder-base-component';
import { IStorageService } from '../services/storage/IStorageService';
import { Subscription } from 'rxjs';
import { SideConfigComponent } from '../components/side-config/side-config.component';
import { FocusContext } from '../services/shortcut.service';
import { preparePageDataForSave } from '../helper/prepare-page-builder-data';
import { InnerContentComponent } from './inner-content/inner-content.component';
import { NGX_PAGE_BUILDER_STORAGE_SERVICE } from '../services/storage/token.storage';
import { PageItemChange } from '../services/page-builder.service';

import {
  DynamicDataStructure,
  IPage,
  IPagebuilderOutput,
  IStyleSheetFile,
  LibConsts,
  Page,
  PageBuilderConfig,
  ViewMode,
  validateViewMode,
  CustomToolbarButtons,
  CMSPage,
  ICssVariable,
  SourceItem,
} from 'ngx-page-builder/core';
import { ClassManagerService } from '../services/class-manager.service';
import { NgxDialogModule, NgxDialogService } from 'ngx-kit/dialog';
import { Notify } from 'ngx-kit/notify';
import { NgxDropListGroup, NgxResizable, type IResizableOutput, NgxResizeHandle } from 'ngx-kit/drag-resize';
import { PanelService } from '../panels/panel.service';
import { NgComponentOutlet } from '@angular/common';
import { ConfigDialogComponent } from '../dialogs/config-dialog/config-dialog.component';
import { NgxIconComponent } from 'ngx-page-builder/icons';

@Component({
  standalone: true,
  selector: 'ngx-page-builder',
  templateUrl: './page-builder.html',
  styleUrls: ['../styles/all.scss'],
  imports: [
    InnerContentComponent,
    ToolbarComponent,
    SideConfigComponent,
    NgxIconComponent,
    NgxDialogModule,
    NgxDropListGroup,
    NgxResizable,
    NgComponentOutlet,
    NgxResizeHandle,
  ],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [PanelService],
})
export class NgxPageBuilder extends PageBuilderBaseComponent implements OnInit, OnDestroy {
  readonly innerContent = viewChild<InnerContentComponent>('innerContent');

  toolbarConfig = LibConsts.toolbarConfig;
  readonly data = input<IPage[]>();

  @Input('config') set setPageConfig(val: PageBuilderConfig | undefined) {
    if (val) {
      this.pb.pageInfo.config = new PageBuilderConfig(val);
    }
  }

  @Input('styles') set setStyles(val: IStyleSheetFile[]) {
    if (val && Array.isArray(val)) {
      for (let f of val) this.cls.addToDefaultStyles(f.data);
    }
  }
  @Input('cssVariables') set setCssVariables(val: ICssVariable[]) {
    if (val && Array.isArray(val)) {
      this.cls.setCssVariables(val);
    }
  }

  @Input('dynamicData') set setDynamicData(val: DynamicDataStructure[]) {
    this.dynamicDataService.dynamicData = val ?? [];
    console.log('ds', this.dynamicDataService.dynamicData);
  }

  @Input({
    alias: 'viewMode',
    transform: validateViewMode,
  })
  set SetViewMode(val: ViewMode) {
    super.viewMode = val;
  }

  @Input() customToolbarButtons: CustomToolbarButtons[] = [];

  /**
   * used in link tag
   */
  @Input('cmsPages') set setCmsPages(val: CMSPage[]) {
    if (val && Array.isArray(val)) {
      LibConsts.cmsPages = val;
    } else {
      LibConsts.cmsPages = [];
    }
  }

  subscriptions: Subscription[] = [];

  showPlugins = LibConsts.showPlugins;

  private storageService = inject<IStorageService>(NGX_PAGE_BUILDER_STORAGE_SERVICE);
  protected readonly dialog = inject(NgxDialogService);
  readonly panelService = inject(PanelService);

  isLoading = signal(false);
  sideConfigSize = signal<number>(270);
  constructor(
    private injector: Injector,
    private cls: ClassManagerService,
  ) {
    super();
    this.pb.storageService = this.storageService;
    this.pb.changed$.subscribe((data: PageItemChange) => {
      if (data.type == 'ChangePageConfig') {
        this.chdRef.detectChanges();
      }
    });

    effect(() => {
      const d = this.data();
      if (!d || Array.isArray(d) == false) {
        console.warn('NgxPageBuilder', 'Input data not valid!');
        Notify.error('Input data not valid!');
        return;
      }
      if (d.length > 0) {
        const pages = d.map((m) => Page.fromJSON(m));
        this.loadPageData(pages);
      }
    });
  }

  async ngOnInit(): Promise<void> {
    this.cls.initialize();
    this.registerShortcuts();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
    this.unregisterShortcuts();
  }

  private async loadPageData(data: Page[]) {
    try {
      this.isLoading.set(true);
      this.pb.pageInfo.pages = data;
      // check has body block
      //console.log('load data:', data, 'converted class:', this.pb.pageInfo);
      if (this.pb.pageInfo.pages.length == 0) {
        await this.pb.addPage();
        this.isLoading.set(false);
      } else {
        setTimeout(async () => {
          await this.pb.changePage(1);
          const body = this.pb.pageInfo.pages[0].bodyItems[0];
          this.isLoading.set(false);
        }, 100);
        //console.log('after load:', this.pb.pageInfo);
      }
    } catch (error) {
      await this.pb.addPage();
      console.error('Error loading page data:', error);
      Notify.error('Error loading page data: ' + error);
      this.isLoading.set(false);
    }
  }

  onResizeSideConfig(ev: IResizableOutput) {
    this.sideConfigSize.set(ev.width);
    this.innerContent()?.updateScale();
  }
  openConfigDialog() {
    this.dialog
      .open(ConfigDialogComponent, {
        size: 'lg',
        header: {
          showMaximizeButton: true,
          showCloseButton: true,
        },
        panelClass: 'ngx-page-builder',
      })
      .afterClosed.subscribe((r) => {
        if (r) {
          this.pb.onUpdateBaseConfig$.next(r);
        }
      });
  }
  /**
   * ✅ Register all page builder shortcuts
   */
  private registerShortcuts(): void {
    // ========================================
    // DELETE - حذف بلاک (فقط در CANVAS context)
    // ========================================
    this.shortcuts.register('delete-block', {
      key: 'Delete',
      contexts: [FocusContext.CANVAS], // 👈 فقط وقتی focus روی canvas است
      description: 'Delete selected block',
      action: async () => {
        const currentBlock = this.pb.activeEl();
        if (currentBlock) {
          await this.pb.removeBlock(currentBlock);
        }
      },
    });

    // همچنین Backspace برای Mac users
    this.shortcuts.register('delete-block-backspace', {
      key: 'Backspace',
      contexts: [FocusContext.CANVAS],
      description: 'Delete selected block',
      action: async () => {
        const currentBlock = this.pb.activeEl();
        if (currentBlock) {
          await this.pb.removeBlock(currentBlock);
        }
      },
    });

    // ========================================
    // COPY - کپی بلاک (فقط در CANVAS)
    // ========================================
    this.shortcuts.register('copy-block', {
      key: 'c',
      ctrl: true,
      contexts: [FocusContext.CANVAS],
      description: 'Copy selected block',
      action: () => {
        const currentBlock = this.pb.activeEl();
        if (currentBlock) {
          this.pb.copyBlock(currentBlock);
        }
      },
    });

    // ========================================
    // PASTE - پیست بلاک (فقط در CANVAS)
    // ========================================
    this.shortcuts.register('paste-block', {
      key: 'v',
      ctrl: true,
      contexts: [FocusContext.CANVAS],
      description: 'Paste copied block',
      action: () => {
        this.pb.pasteBlock();
      },
    });

    // ========================================
    // DUPLICATE - دوبل کردن بلاک
    // ========================================
    this.shortcuts.register('duplicate-block', {
      key: 'd',
      ctrl: true,
      contexts: [FocusContext.CANVAS],
      description: 'Duplicate selected block',
      action: () => {
        const currentBlock = this.pb.activeEl();
        if (currentBlock) {
          this.pb.duplicateBlock(currentBlock);
        }
      },
    });

    // ========================================
    // UNDO / REDO
    // ========================================
    this.shortcuts.register('undo', {
      key: 'z',
      ctrl: true,
      contexts: [FocusContext.CANVAS, FocusContext.SIDEBAR], // در canvas و sidebar
      description: 'Undo last action',
      action: () => {
        this.pb.undo();
      },
    });

    this.shortcuts.register('redo', {
      key: 'z',
      ctrl: true,
      shift: true,
      contexts: [FocusContext.CANVAS, FocusContext.SIDEBAR],
      description: 'Redo last action',
      action: () => {
        this.pb.redo();
      },
    });

    // ========================================
    // ESCAPE - لغو انتخاب
    // ========================================
    this.shortcuts.register('deselect', {
      key: 'Escape',
      contexts: [FocusContext.CANVAS, FocusContext.TEXT_EDITING],
      description: 'Deselect / Exit edit mode',
      action: () => {
        const context = this.shortcuts.getCurrentContext();
        if (context === FocusContext.TEXT_EDITING) {
          // خروج از حالت ویرایش متن
          (this.doc.activeElement as HTMLElement)?.blur();
        } else {
          // لغو انتخاب بلاک
          this.pb.deSelectBlock();
        }
      },
    });

    // ========================================
    // SAVE - ذخیره (در همه context ها)
    // ========================================
    this.shortcuts.register('save', {
      key: 's',
      ctrl: true,
      contexts: [FocusContext.CANVAS, FocusContext.TEXT_EDITING, FocusContext.SIDEBAR],
      description: 'Save page',
      action: () => {
        this.pb.save();
      },
    });

    // ========================================
    // ARROW KEYS - حرکت بلاک (فقط در CANVAS)
    // ========================================
    // const moveDistance = 1;
    // const moveDistanceLarge = 10;

    // this.shortcuts.register('move-up', {
    //   key: 'ArrowUp',
    //   contexts: [FocusContext.CANVAS],
    //   description: 'Move block up',
    //   action: (event) => {
    //     const distance = event.shiftKey ? moveDistanceLarge : moveDistance;
    //     this.pb.moveActiveBlock(0, -distance);
    //   },
    // });

    // this.shortcuts.register('move-down', {
    //   key: 'ArrowDown',
    //   contexts: [FocusContext.CANVAS],
    //   description: 'Move block down',
    //   action: (event) => {
    //     const distance = event.shiftKey ? moveDistanceLarge : moveDistance;
    //     this.pb.moveActiveBlock(0, distance);
    //   },
    // });

    // this.shortcuts.register('move-left', {
    //   key: 'ArrowLeft',
    //   contexts: [FocusContext.CANVAS],
    //   description: 'Move block left',
    //   action: (event) => {
    //     const distance = event.shiftKey ? moveDistanceLarge : moveDistance;
    //     this.pb.moveActiveBlock(-distance, 0);
    //   },
    // });

    // this.shortcuts.register('move-right', {
    //   key: 'ArrowRight',
    //   contexts: [FocusContext.CANVAS],
    //   description: 'Move block right',
    //   action: (event) => {
    //     const distance = event.shiftKey ? moveDistanceLarge : moveDistance;
    //     this.pb.moveActiveBlock(distance, 0);
    //   },
    // });

    // ========================================
    // debuge log pageinfo
    // ========================================
    this.shortcuts.register('logconsole', {
      key: 'p',
      ctrl: true,
      shift: true,
      alt: true,
      contexts: [FocusContext.CANVAS, FocusContext.TEXT_EDITING, FocusContext.SIDEBAR],
      description: 'log console',
      action: () => {
        console.log(this.pb.pageInfo);
      },
    });
  }

  /**
   * ✅ Unregister shortcuts
   */
  private unregisterShortcuts(): void {
    const shortcutIds = [
      'delete-block',
      'delete-block-backspace',
      'copy-block',
      'paste-block',
      'duplicate-block',
      'undo',
      'redo',
      'select-all',
      'deselect',
      'save',
      'move-up',
      'move-down',
      'move-left',
      'move-right',
    ];

    shortcutIds.forEach((id) => this.shortcuts.unregister(id));
  }

  /**
   * Get page builder data for save to DB
   * @returns Promise JSONData
   */
  public getData(): Promise<IPagebuilderOutput> {
    return new Promise(async (resolve, reject) => {
      try {
        const data = await preparePageDataForSave(this.pb);
        resolve(data);
      } catch (error) {
        reject(error);
      }
    });
  }

  async addItem(item: SourceItem) {
    await this.pb.addBlockToBody(item);
    console.log(this.pb);
  }
}
