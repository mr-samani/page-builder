import {
  Component,
  ElementRef,
  OnInit,
  ChangeDetectionStrategy,
  viewChild,
  ApplicationRef,
  DOCUMENT,
  inject,
  Injector,
  computed,
  signal,
  effect,
} from '@angular/core';
import { PageBuilderBaseComponent } from '../page-builder-base-component';
import { DynamicElementService, LibConsts } from 'ngx-page-builder/core';
import { createApplication } from '@angular/platform-browser';
import { BaseContentComponent } from './base-content';
import { PageBuilderService } from '../../services/page-builder.service';
import { DragDropService } from 'ngx-kit/drag-resize';
import { ALL_ICONS, provideIcons } from 'ngx-page-builder/icons';

@Component({
  selector: 'inner-content',
  template: `
    <div class="canvas" #canvas>
      <!-- عرض iframe برابر minWidth همان breakpoint است تا media query های همان breakpoint واقعاً فعال شوند -->
      <iframe
        #iframe
        [style.width.px]="canvasWidth()"
        [style.minWidth.px]="canvasWidth()"
        [style.maxWidth.px]="canvasWidth()"
        [style.transform]="'scale(' + scale() + ')'"></iframe>
    </div>
  `,
  styles: `
    :host {
      display: block;
      height: 100%;
    }
    .canvas {
      height: 100%;
      overflow: hidden;
    }
    iframe {
      height: 100%;
      border: none;
      margin: 0 auto;
      display: block;
      box-shadow: 0 0 7px 0px #4f4f4f;
      transition: width 200ms ease;
      transform-style: preserve-3d;
      transform-origin: 0 0;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
})
export class InnerContentComponent extends PageBuilderBaseComponent implements OnInit {
  private readonly iframe = viewChild.required<ElementRef<HTMLIFrameElement>>('iframe');
  private readonly canvas = viewChild.required<ElementRef<HTMLIFrameElement>>('canvas');

  private iframeApp?: ApplicationRef;
  protected readonly injector = inject(Injector);

  readonly scale = signal(1);
  protected readonly canvasWidth = computed(() => this.pb.responsive().minWidth);

  constructor() {
    super();
    this.pb.onUpdateBaseConfig$.subscribe((c) => {
      if (c) this.updateBodyStyle();
    });
    effect(() => {
      const mw = this.pb.responsive().minWidth;
      this.updateScale();
    });
  }

  ngOnInit() {
    this.loadIframe();
  }

  updateScale() {
    const mw = this.pb.responsive().minWidth;
    const c = this.canvas().nativeElement.getBoundingClientRect();
    this.scale.set(Math.min(c.width / mw, 1));
  }
  async loadIframe() {
    const iframe = this.iframe()?.nativeElement;
    if (!iframe) return;

    const doc = iframe.contentDocument!;

    // clean previous data
    doc.body.innerHTML = '';
    const host = doc.createElement('ngx-page-builder-context');
    doc.body.appendChild(host);

    const drp = this.injector.get(DragDropService);
    // create new Angular Application Instance
    this.iframeApp = await createApplication({
      providers: [
        provideIcons(ALL_ICONS),
        // خیلی مهم:
        // Angular را مجبور می‌کنیم DOCUMENT را
        // همان document مربوط به iframe بداند.
        {
          provide: DOCUMENT,
          useValue: doc,
        },
        {
          provide: DragDropService,
          useValue: drp,
        },
        {
          provide: PageBuilderService,
          useValue: this.pb,
        },
      ],
    });

    // بلاک‌های سفارشی باید با application ی iframe ساخته شوند تا استایل کامپوننت‌هایشان
    // داخل <head> ی iframe نوشته شود (نه document اصلی). قبل از ساخت اولین بلاک ثبت می‌شود.
    this.injector.get(DynamicElementService).registerDocument(doc, this.iframeApp.injector);

    // کامپوننت Angular را داخل iframe bootstrap می‌کنیم
    this.iframeApp.bootstrap(BaseContentComponent, {
      hostElement: host,
    });
    this.pb.cls.setIframe(iframe);
    this.updateBodyStyle();
    this.loadJs();
  }

  private updateBodyStyle() {
    const iframe = this.iframe()?.nativeElement;
    if (!iframe) return;
    const doc = iframe.contentDocument!;
    const s = `${this.siteSettingsToCss()}
    ngx-page-builder-context{
      height: 100%;
      display: block;
    }
    *{
      box-sizing:border-box;
    }
    `;

    let style = doc.head.querySelector('#ngx-page-context-base-style');
    if (!style) {
      style = doc.createElement('style');
      style.id = 'ngx-page-context-base-style';
      doc.head.appendChild(style);
    }
    style.innerHTML = s;
  }

  private loadJs() {
    const iframe = this.iframe()?.nativeElement;
    if (!iframe) return;
    const doc = iframe.contentDocument!;

    for (let js of LibConsts.publicJs) {
      const j = this.doc.createElement('script');
      j.src = js;
      j.id = js.split('/').pop()?.split('.').at(0) ?? 'publicJs-' + Math.random() * 10000;
      doc.head.appendChild(j);
    }
  }

  ngOnDestroy() {
    const doc = this.iframe()?.nativeElement.contentDocument;
    if (doc) this.injector.get(DynamicElementService).unregisterDocument(doc);
    this.iframeApp?.destroy();
  }

  siteSettingsToCss(): string {
    const s = this.pb.pageInfo.config;

    return `body {
      --pb-font-family: ${s.fontFamily};
      --pb-base-font-size: ${s.baseFontSize ?? '16px'};
      --pb-color-text: ${s.color ?? 'inherit'};
      --pb-color-background: ${s.backgroundColor ?? 'inherit'};
      color-scheme: ${s.colorScheme};
      direction: ${s.direction};
      font-family: var(--pb-font-family);
      font-size: var(--pb-base-font-size);
      color: var(--pb-color-text, inherit);
      background: var(--pb-color-background, transparent);

      
      margin:0;
      padding:0;
      height:100%; 
      overflow-y:scroll;
    }`;
  }
}
