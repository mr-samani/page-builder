import { ChangeDetectorRef, Component, inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { ImportHtmlService } from '../../services/import-export/import-html.service';
import { ImportResult } from '../../services/import-export/ImportResult';
import { ImportOptions } from '../../services/import-export/ImportOptions';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PreviewImportTreeComponent } from './preview-import-tree/preview-import-tree.component';
import { TabGroupModule } from '../../controls/tab-group/tab-group.module';
import { LoadingComponent } from '../../controls/loading/loading.component';
import { LibConsts } from 'ngx-page-builder/core';
import { NgxDialogModule, DIALOG_REF } from 'ngx-kit/dialog';
import { Notify } from 'ngx-kit/notify';

@Component({
  selector: 'app-import-dialog',
  templateUrl: './import-dialog.component.html',
  styleUrls: ['./import-dialog.component.scss'],
  imports: [CommonModule, FormsModule, NgxDialogModule, PreviewImportTreeComponent, TabGroupModule, LoadingComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ImportHtmlService],
})
export class ImportDialogComponent implements OnInit {
  urlInput = '';
  querySelectorInput = '';
  htmlInput = '';
  result?: ImportResult;

  // تنظیمات پیشرفته
  importOptions: ImportOptions = {
    preserveInlineStyles: true,
    extractComputedStyles: true,
    spaWaitTime: 20000,
  };

  showBackendapiCheckbox = LibConsts.backendProxyImportUrl != '';
  useBackendApi = false;

  loading: boolean = false;
  private dialogRef = inject(DIALOG_REF);

  constructor(
    private importer: ImportHtmlService,
    private chdr: ChangeDetectorRef,
  ) {}

  ngOnInit() {}

  importFromUrl(resultSection: HTMLElement) {
    if (!this.urlInput || !this.querySelectorInput) {
      Notify.warning('لطفاً URL و Query Selector را وارد کنید');
      return;
    }
    this.result = undefined;
    this.loading = true;

    let api;
    if (this.useBackendApi) {
      api = this.importer.importFromUrlWithBackend(
        this.urlInput,
        this.querySelectorInput,
        LibConsts.backendProxyImportUrl,
        this.importOptions,
      );
    } else {
      api = this.importer.importFromUrl(this.urlInput, this.querySelectorInput, this.importOptions);
    }

    api
      .finally(() => (this.loading = false))
      .then((result) => {
        this.result = result;
        console.log(result);
        Notify.success('Import successfully');
        setTimeout(() => {
          resultSection.scrollIntoView();
        }, 100);
        this.chdr.detectChanges();
      });
  }

  async importFromHtml(resultSection: HTMLElement) {
    if (!this.htmlInput) {
      Notify.warning('لطفاً محتوای HTML را وارد کنید');
      return;
    }
    this.result = undefined;
    this.loading = true;
    this.importer
      .importFromHtml(this.htmlInput, this.querySelectorInput, this.importOptions)
      .finally(() => (this.loading = false))
      .then((result) => {
        this.result = result;
        console.log(result);
        Notify.success('Import successfully');
        setTimeout(() => {
          resultSection.scrollIntoView();
        }, 100);
        this.chdr.detectChanges();
      });
  }

  ok() {
    if (this.loading || !this.result || !this.result.data) return;
    this.dialogRef.close(this.result.data);
  }
}
