import {
  AfterContentInit,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  Output,
  QueryList,
  ChangeDetectionStrategy,
} from '@angular/core';
import { TabItemComponent } from '../tab-item/tab-item.component';

@Component({
  standalone: false,
  selector: 'tab-group',
  templateUrl: './tab-group.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./tab-group.component.scss'],
})
export class TabGroupComponent implements AfterContentInit {
  @Input() showPlusButton = false;
  @Input() dontShowSingleTab = true;
  @Output() onAddTab = new EventEmitter();

  _selectedIndex?: number;
  /**
   * index started from zero
   */
  @Input('selectedIndex') set selectedIndex(val: number) {
    if (this._selectedIndex == val) {
      return;
    }
    const selectedTab = this.tabs?.get(val);
    if (selectedTab) {
      this.tabs?.toArray().forEach((tab) => (tab.active = false));
      selectedTab.active = true;
    }
  }
  @Output() selectedIndexChange = new EventEmitter<number>();
  @ContentChildren(TabItemComponent) tabs?: QueryList<TabItemComponent>;
  rndId = Math.round(Math.random() * 5000);

  /** toggle tab item menu in tablet or mobile */
  openTabItemMenu = false;
  constructor(private chdr: ChangeDetectorRef) {}

  ngAfterContentInit() {
    setTimeout(() => {
      if (!this.tabs) return;
      // get all active tabs
      let activeTabs = this.tabs.filter((tab) => tab.active);
      // if there is no active tab set, activate the first
      if (activeTabs.length === 0) {
        this.selectTab(this.tabs.first, 0);
      }
    }, 0);
  }

  selectTab(tab: TabItemComponent, index: number) {
    if (!tab || !this.tabs) {
      return;
    }
    // deactivate all tabs
    this.tabs.toArray().forEach((tab) => (tab.active = false));
    // activate the tab the user has clicked on.
    tab.active = true;
    this._selectedIndex = index;
    this.selectedIndexChange.emit(index);
    this.chdr.detectChanges();
  }

  onClickPlus() {
    this.onAddTab.emit();
  }
}
