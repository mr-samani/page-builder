import { CommonModule } from '@angular/common';
import { Component, forwardRef, inject, input, OnInit, output, ChangeDetectionStrategy } from '@angular/core';
import { ControlValueAccessor, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgxInputColor } from 'ngx-kit/color-picker';
import { NgxInputGradient } from 'ngx-kit/gradient-picker';
import { CssValueType, ICssVariable, LibConsts } from 'ngx-page-builder/core';
import { MenuDialog } from '../../extensions/menu-dialog/menu-dialog.component';
import { NgxIconComponent } from 'ngx-page-builder/icons';
import { ClassManagerService } from '../../services/class-manager.service';
import { NgxDialogService } from 'ngx-kit/dialog';
import { CssVariablesDialogComponent } from '../../dialogs/css-variables-dialog/css-variables-dialog.component';

@Component({
  selector: 'input-css',
  templateUrl: './input-css.component.html',
  styleUrls: ['./input-css.component.scss'],
  imports: [CommonModule, FormsModule, NgxInputColor, NgxInputGradient, MenuDialog, NgxIconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputCssComponent),
      multi: true,
    },
  ],
})
export class InputCssComponent implements OnInit, ControlValueAccessor {
  type = input<CssValueType>('Text');
  title = input<string>('');

  value?: string;

  public valueChange = output<string | undefined>();

  private _onChange = (val?: string) => {};
  private _onChangeValidate = () => {};
  private _onTouched = () => {};
  disabled = false;

  enableCssVariable = LibConsts.enableCssVariable;
  filterCssVar = '';
  filteredCssVars: ICssVariable[] = [];

  thisIsVariable = false;
  variableName = '';

  protected readonly cls = inject(ClassManagerService);
  protected readonly dialog = inject(NgxDialogService);

  constructor() {}

  ngOnInit() {
    this.searchCssVariable();
  }
  writeValue(val?: string): void {
    this.value = val;
    this.getVariableName();
  }
  registerOnChange(fn: any): void {
    this._onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  clear() {
    this.value = undefined;
    this.getVariableName();

    this.onChange();
  }
  onChange() {
    this.getVariableName();
    this._onChange(this.value);
    this.valueChange.emit(this.value);
  }

  openCssVariableDialog(menuDialog: MenuDialog) {
    if (!this.enableCssVariable) return;
    menuDialog.showModal();
  }

  /*---------------------CSS Variables----------------------------------*/
  private getVariableName() {
    if (!this.value) {
      this.thisIsVariable = false;
      this.variableName = '';
      return;
    }
    this.thisIsVariable = this.value.trim().startsWith('var(--') == true;
    if (this.thisIsVariable) {
      this.variableName = this.value
        .trim()
        .replace('var(--', '')
        .substring(0, this.value.length - 7);
    } else {
      this.variableName = '';
    }

    console.log(this.value, this.thisIsVariable, this.variableName);
  }
  searchCssVariable() {
    this.filteredCssVars = this.cls.cssVariables.filter(
      (x) => x.type == this.type() && x.name.toLowerCase().includes(this.filterCssVar.toLowerCase()),
    );
  }
  selectCssVar(item: ICssVariable, menuDialog: MenuDialog) {
    this.value = `var(--${item.name})`;
    this.onChange();
    menuDialog.closeModal();
  }
  async openCssVariablesDialog(menuDialog: MenuDialog) {
    menuDialog.closeModal();
    this.dialog
      .open(CssVariablesDialogComponent, {
        header: {
          showMaximizeButton: true,
          showCloseButton: true,
        },
        panelClass: 'ngx-page-builder',
      })
      .afterClosed.subscribe(() => this.searchCssVariable());
  }
}
