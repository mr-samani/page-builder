import { DOCUMENT, inject, Injectable, model, OnDestroy, signal } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { HistoryService } from './history.service';
import { IStorageService } from './storage/IStorageService';

import {
  DEFAULT_FIRST_BREAKPOINT,
  DynamicElementService,
  IPageItem,
  LibConsts,
  LOCAL_STORAGE_SHOW_OUTLINE_KEY,
  Page,
  PageBuilderDto,
  PageConfig,
  PageItem,
  SourceItem,
  cloneDeep,
  BlockCss,
  Breakpoint,
} from 'ngx-page-builder/core';
import { getDefaultBlockClasses, getDefaultBlockDirective } from '../helper/getDefaultBlockDirective';
import { ClassManagerService } from '../services/class-manager.service';
import { Notify } from 'ngx-kit/notify';
import { IDropEvent } from 'ngx-kit/drag-resize';

/** بخش‌های صفحه: header / footer فقط در حالت PrintPage وجود دارند */
export type PageZone = 'header' | 'body' | 'footer';

/** مقصد جابجایی: یا داخل یک بلاک (parent) یا مستقیماً ریشه‌ی یکی از بخش‌های صفحه (zone) */
export interface MoveTarget {
  parent?: PageItem;
  zone?: PageZone;
}

export interface PageItemChange {
  item: PageItem | null;
  parent?: PageItem[];
  type:
    | 'ChangePageConfig'
    | 'AddBlock'
    | 'ChangeBlockContent'
    | 'ChangeBlockProperties'
    | 'RemoveBlock'
    | 'MoveBlock'
    | 'ChangeTagName'
    | 'ChangeClassName';
}

@Injectable({ providedIn: 'root' })
export class PageBuilderService implements OnDestroy {
  isSaving: boolean = false;
  sources: SourceItem[] = LibConsts.SourceItemList;
  pageHeaderEl?: HTMLElement;
  pageBodyEl?: HTMLElement;
  pageFooterEl?: HTMLElement;

  responsive = signal<Breakpoint>(DEFAULT_FIRST_BREAKPOINT);

  /** start from 0 */
  currentPageIndex = signal<number>(0);
  activeEl = signal<PageItem | undefined>(undefined);
  showOutlines = signal(true);
  pageInfo = new PageBuilderDto();

  private _changed$ = new Subject<PageItemChange>();
  /** تغییر کردن pageitem ها */
  changed$ = this._changed$.asObservable();

  /** جابجایی بین صفحات */
  onPageChange$ = new BehaviorSubject<Page | undefined>(undefined);
  onSelectBlock$ = new BehaviorSubject<{ ev?: PointerEvent; item: PageItem } | undefined>(undefined);
  onUpdateBaseConfig$ = new BehaviorSubject<PageConfig | undefined>(undefined);

  storageService!: IStorageService;

  copyStorage?: PageItem;
  protected readonly doc = inject(DOCUMENT);
  protected readonly dynamicElementService = inject(DynamicElementService);
  protected readonly history = inject(HistoryService);
  readonly cls = inject(ClassManagerService);

  constructor() {
    const so = localStorage.getItem(LOCAL_STORAGE_SHOW_OUTLINE_KEY) || '';
    if (so != '') {
      this.showOutlines.set(so == 'true');
    }
  }

  ngOnDestroy(): void {
    this._changed$.complete();
    this.onPageChange$.unsubscribe();
    this.onSelectBlock$.unsubscribe();
    this.onUpdateBaseConfig$.unsubscribe();
    this.history.clear();
    this.cls.destroy();

    this.onPageChange$ = new BehaviorSubject<Page | undefined>(undefined);
    this.onSelectBlock$ = new BehaviorSubject<{ ev?: PointerEvent; item: PageItem } | undefined>(undefined);
    this.onUpdateBaseConfig$ = new BehaviorSubject<PageConfig | undefined>(undefined);
  }

  async reset() {
    await this.removeAllPages();
    this.pageInfo = new PageBuilderDto();
    this.history.clear();
  }

  new() {
    this.reset();
  }

  updateChangeDetection(data: PageItemChange) {
    this._changed$.next(data);
  }

  public get currentPage(): Page | undefined {
    return this.pageInfo.pages[this.currentPageIndex()];
  }
  public set currentPage(page: Page) {
    if (!this.pageInfo.pages[this.currentPageIndex()]) {
      throw new Error('Current page does not exist');
    }
    this.pageInfo.pages[this.currentPageIndex()] = page;
  }

  async onDrop(event: IDropEvent<PageItem[]>, parent?: PageItem) {
    console.log('Dropped:', event);
    const containerEl = event.container.el;
    const previousEl = event.previousContainer.el;
    if (!event.container.data || !event.previousContainer.data) {
      return;
    }
    if (containerEl == previousEl && event.currentIndex == event.previousIndex) {
      return;
    }
    const dragItem: PageItem = event.previousContainer.data[event.previousIndex];
    if (!dragItem) {
      console.warn('Block not found in previus container!');
      return;
    }

    this.activeEl.set(undefined);
    if (event.previousContainer.el.classList.contains('blockSourceList')) {
      // انتقال از یک container به container دیگه
      const sourceItem = event.previousContainer.data[event.previousIndex] as unknown as SourceItem;
      if (!sourceItem) return;
      const source = this.createPageItemFromSource(sourceItem, parent);
      await this.createBlockElement(true, source, containerEl, event.currentIndex);

      event.container.data.splice(event.currentIndex, 0, source);
      this.selectBlock(source);
      this.updateChangeDetection({ item: source, parent: event.container.data, type: 'AddBlock' });

      this.history.saveAdd(parent?.id, event.currentIndex, source, `Add block'${source.id}' to '${parent?.id}'`);
    } else {
      // بررسی اجازه جابجایی در ایتم های کالکشن (لیست تکرار شونده)
      if (this.canMove(dragItem, event.container) == false) {
        Notify.warning('You cannot move this item here.');
        return;
      }

      await this.removeBlock(dragItem);
      dragItem.parent = parent;
      await this.createBlockElement(true, dragItem, containerEl, event.currentIndex);

      event.container.data.splice(event.currentIndex, 0, dragItem);

      this.updateChangeDetection({
        item: event.container.data[event.currentIndex],
        parent: event.container.data,
        type: 'MoveBlock',
      });

      this.history.saveMove(
        dragItem.id,
        dragItem.parent?.id,
        event.previousIndex,
        event.container.data[event.currentIndex]?.parent?.id,
        event.currentIndex,
        event.container.data[event.currentIndex],
        `Move block '${dragItem.id}' from: '${dragItem.parent?.id}' to: '${
          event.container.data[event.currentIndex]?.parent?.id
        }'`,
      );
    }

    // console.log('ev', event.container.data, 'p', this.pageInfo.pages);
    // this.chdRef.detectChanges();
    this.onPageChange$.next(this.currentPage);
  }

  /** Build a fresh PageItem tree from a source definition, including useful starter children. */
  private createPageItemFromSource(source: SourceItem, parent?: PageItem): PageItem {
    const item = new PageItem(source, parent);
    // Source definitions are registry singletons: never let an inserted block mutate their shared metadata.
    item.options = cloneDeep(source.options);
    item.classList = [...(source.classList ?? [])];
    item.css = cloneDeep(source.css);
    item.customComponent = cloneDeep(source.customComponent);
    item.children = (source.initialChildren ?? []).map((child) => this.createPageItemFromSource(child, item));
    return item;
  }

  public async addBlockToBody(item: SourceItem) {
    if (!this.currentPage) return;
    const source = this.createPageItemFromSource(item);
    await this.createBlockElement(true, source);
    this.selectBlock(source);
    this.updateChangeDetection({ item: source, type: 'AddBlock' });
    this.currentPage.bodyItems.push(source);
    this.history.saveAdd('', 0, source, `Add block'${source.id}' to 'body'`);
  }

  /**
   * in collection item list only can move element in inner self template
   * @param source current drag item
   * @param destination destination drop list
   * @returns boolean
   */
  private canMove(source: PageItem, destination: any): boolean {
    if (source.disableMovement) return false;
    let p = this.getParentTemplate(source);
    if (!p || !p.lockMoveInnerChild) return true;
    return destination.el.closest('.template-container') == p.el;
  }

  getParentTemplate(item: PageItem): PageItem | undefined {
    if (!item || !item.parent) return undefined;
    if (item.parent.isTemplateContainer) {
      return item.parent;
    }
    return this.getParentTemplate(item.parent);
  }

  //---------------------------------- جابجایی بلاک (درخت Layouts / دکمه‌های Move) ----------------------------------

  /** آرایه‌ی ریشه‌ی یک بخش از صفحه‌ی فعلی (همان آرایه‌ی واقعی، نه کپی) */
  getZoneList(zone: PageZone): PageItem[] | undefined {
    const page = this.currentPage;
    if (!page) return undefined;
    return zone === 'header' ? page.headerItems : zone === 'footer' ? page.footerItems : page.bodyItems;
  }

  /** بلاک داخل کدام بخش از صفحه است؟ */
  getItemZone(item: PageItem): PageZone | undefined {
    const page = this.currentPage;
    if (!page) return undefined;
    let root = item;
    while (root.parent) root = root.parent;
    const has = (list: PageItem[]) => list.some((i) => i === root || i.id === root.id);
    if (has(page.bodyItems)) return 'body';
    if (has(page.headerItems)) return 'header';
    if (has(page.footerItems)) return 'footer';
    return undefined;
  }

  private zoneEl(zone: PageZone): HTMLElement | undefined {
    return zone === 'header' ? this.pageHeaderEl : zone === 'footer' ? this.pageFooterEl : this.pageBodyEl;
  }

  /** آیا `ancestor` پدر (مستقیم یا غیرمستقیم) `item` است؟ */
  private isAncestorOf(ancestor: PageItem, item: PageItem): boolean {
    for (let p = item.parent; p; p = p.parent) if (p === ancestor || p.id === ancestor.id) return true;
    return false;
  }

  /**
   * آیا این جابجایی مجاز است؟
   * @returns null اگر مجاز است؛ وگرنه متن دلیل (برای نمایش به کاربر)
   */
  checkMove(item: PageItem, target: MoveTarget): string | null {
    if (item.disableMovement) return 'This block cannot be moved.';
    const parent = target.parent;
    if (parent) {
      if (parent === item || parent.id === item.id || this.isAncestorOf(item, parent)) {
        return 'A block cannot be moved into itself.';
      }
      if (!parent.canHaveChild || parent.customComponent) return `<${parent.tag}> cannot contain other blocks.`;
    } else if (!this.getZoneList(target.zone ?? 'body')) {
      return 'The destination is not available.';
    }
    // آیتم‌های کالکشن فقط داخل خودِ قالب خودشان جابجا می‌شوند
    const tpl = this.getParentTemplate(item);
    if (tpl?.lockMoveInnerChild) {
      let inside = false;
      for (let p = parent; p; p = p.parent) {
        if (p === tpl || p.id === tpl.id) {
          inside = true;
          break;
        }
      }
      if (!inside) return 'This item can only be moved inside its own list.';
    }
    return null;
  }

  /**
   * بلاک را به مقصد جدید می‌برد (المنت، لیست‌ها، CSS، history و رویداد MoveBlock را هماهنگ نگه می‌دارد).
   * @param index موقعیت «نهایی» بلاک در لیست مقصد (بعد از برداشتن از جای قبلی)، مثل moveItemInArray
   * @returns true اگر واقعاً جابجا شد
   */
  async moveBlock(item: PageItem, target: MoveTarget, index: number): Promise<boolean> {
    const reason = this.checkMove(item, target);
    if (reason) {
      Notify.warning(reason);
      return false;
    }

    const fromParent = item.parent;
    const fromList = fromParent?.children ?? this.findRootParentItem(item);
    const fromZone = this.getItemZone(item);
    const toZone = target.parent ? this.getItemZone(target.parent) : (target.zone ?? 'body');
    const toList = target.parent ? target.parent.children : this.getZoneList(toZone!);
    const toEl = target.parent ? target.parent.el : this.zoneEl(toZone!);
    if (!fromList || !fromZone || !toZone || !toList || !toEl) {
      Notify.warning('The destination is not available.');
      return false;
    }

    const fromIndex = fromList.indexOf(item);
    if (fromIndex < 0) return false;
    const sameList = fromList === toList;
    const toIndex = Math.min(Math.max(0, index), sameList ? toList.length - 1 : toList.length);
    if (sameList && toIndex === fromIndex) return false;

    const fromEl = fromParent ? fromParent.el : this.zoneEl(fromZone);
    this.flushStyleChange();
    this.activeEl.set(undefined);

    // برداشتن از جای قبلی (مثل removeBlock ولی بدون history ی «delete» و بدون چک disableDelete)
    fromList.splice(fromIndex, 1);
    await this.dynamicElementService.destroy(item);
    await this.cls.removeBlockCss(item);

    try {
      item.parent = target.parent;
      const el = await this.createBlockElement(true, item, toEl, toIndex);
      if (el) item.el = el;
      toList.splice(toIndex, 0, item);
    } catch (e) {
      // بازگرداندن به جای قبلی تا بلاک از مدل گم نشود
      console.error('moveBlock failed, rolling back', e);
      item.parent = fromParent;
      if (!fromList.includes(item)) fromList.splice(fromIndex, 0, item);
      try {
        const el = await this.createBlockElement(true, item, fromEl, fromIndex);
        if (el) item.el = el;
      } catch (e2) {
        console.error('rollback failed', e2);
      }
      Notify.error('Moving the block failed.');
      return false;
    }

    this.updateChangeDetection({ item, parent: toList, type: 'MoveBlock' });
    // history فقط روی bodyItems کار می‌کند (undo/redo ی toolbar)؛ جابجایی از/به header و footer ثبت نمی‌شود
    if (fromZone === 'body' && toZone === 'body') {
      this.history.saveMove(
        item.id,
        fromParent?.id,
        fromIndex,
        target.parent?.id,
        toIndex,
        item,
        `Move block '${item.id}' from: '${fromParent?.id ?? 'body'}' to: '${target.parent?.id ?? 'body'}'`,
      );
    }
    this.onPageChange$.next(this.currentPage);
    this.selectBlock(item);
    return true;
  }

  async addPage(): Promise<number> {
    let index = this.currentPageIndex() + 1;
    this.pageInfo.pages.splice(index, 0, new Page());
    const c = await this.changePage(index + 1);
    return c;
  }

  async removePage(): Promise<number> {
    let index = this.currentPageIndex();
    if (index > -1) {
      await this.cleanCanvas(index);
      this.pageInfo.pages.splice(index, 1);
      if (this.pageInfo.pages.length == 0) {
        return this.addPage();
      } else {
        if (index == 0) {
          index++;
        }
        return await this.changePage(index);
      }
    }
    throw Error('Invalid page index');
  }

  /**
   * clean all pages
   * @returns
   */
  async removeAllPages(): Promise<void> {
    try {
      this.deSelectBlock();
      for (let i = 0; i < this.pageInfo.pages.length; i++) {
        const sections = [
          ...this.pageInfo.pages[i].headerItems,
          ...this.pageInfo.pages[i].bodyItems,
          ...this.pageInfo.pages[i].footerItems,
        ];
        for (let index = 0; index < sections.length; index++) {
          await this.cleanCanvas(index);
        }
      }
      this.pageInfo.pages = [new Page()];
      this.currentPageIndex.set(0);
      return;
    } catch (error) {
      // console.error( error);
    }
  }

  async nextPage(): Promise<number> {
    let index = this.currentPageIndex();
    if (index < this.pageInfo.pages.length - 1) {
      return await this.changePage(index + 2);
    }
    throw Error('No next page');
  }
  async previousPage(): Promise<number> {
    let index = this.currentPageIndex();
    if (index > 0) {
      return await this.changePage(index);
    }
    throw Error('No previous page');
  }

  /**
   * Change the current page
   * @param pageNumber start from 1
   */
  async changePage(pageNumber: number): Promise<number> {
    try {
      this.deSelectBlock();
      if (pageNumber == undefined || pageNumber == null) {
        throw Error('Required page number');
      }
      if (pageNumber < 1 || pageNumber > this.pageInfo.pages.length) {
        throw Error('Invalid page number');
      } else {
        await this.cleanCanvas(this.currentPageIndex());
        const { headerItems, bodyItems, footerItems } = this.pageInfo.pages[pageNumber - 1];
        await this.genElms(bodyItems, this.pageBodyEl);
        if (LibConsts.viewMode == 'PrintPage') {
          await this.genElms(headerItems, this.pageHeaderEl);
          await this.genElms(footerItems, this.pageFooterEl);
        }
        this.currentPageIndex.set(pageNumber - 1);
        this.onPageChange$.next(this.pageInfo.pages[this.currentPageIndex()]);
        return this.currentPageIndex();
      }
    } catch (error) {
      console.error('Error changing page:', error);
      throw error;
    }
  }

  /**
   * update current page body blocks
   * @param blocks body blocks
   * @returns
   */
  async updatePage(blocks: PageItem[]): Promise<void> {
    try {
      if (!this.currentPage) {
        Notify.error('Page Not Exist!');
        throw Error('Page Not Exist!');
      }
      this.currentPage.bodyItems = blocks;
      await this.changePage(this.currentPageIndex() + 1);
    } catch (error) {
      console.error('Error updating page:', error);
      throw Error('Error updating page');
    }
  }

  private async genElms(list: PageItem[], container?: HTMLElement, index = -1) {
    if (!container) {
      throw new Error('ContainerNotFound');
    }
    for (let i = 0; i < list.length; i++) {
      list[i].el = await this.createBlockElement(true, list[i], container, index);
    }
  }
  async reloadCurrentPage() {
    await this.changePage(this.currentPageIndex() + 1);
  }

  /**
   *  ایجاد المنت جدید حتما باید با await انجام شود
   */
  async createBlockElement(editMode: boolean, item: PageItem, container?: HTMLElement | null, index: number = -1) {
    if (!container) {
      container = this.pageBodyEl;
    }
    if (!container) {
      throw new Error('Required container to create element');
    }
    // فقط خودِ بلاک؛ فرزندان در حلقه‌ی پایین با createBlockElement خودشان اعمال می‌شوند (بدون پیمایش تکراری درخت)
    if (item.css) {
      this.cls.addBlockCss(item, false);
    }
    if (editMode) {
      item.options ??= {};
      item.options.directives ??= [];
      item.options.directives = await getDefaultBlockDirective(item, (ev: IDropEvent<PageItem[]>) => {
        this.onDrop(ev, item);
      });

      if (item.options.directives.length >= 4) {
        throw new Error('Too many directives');
      }
      item.options.attributes ??= {};
      const classNames = getDefaultBlockClasses(item);
      if (item.classList.indexOf(classNames) == -1) {
        item.classList.push(classNames);
      }
      item.options.events ??= {};
      item.options.events['click'] = (ev: PointerEvent) => this.selectBlock(item, ev);
    }
    let el = await this.dynamicElementService.createBlock(LibConsts.SourceItemList, editMode, container, index, item);
    if (!item.customComponent && item.children && item.children.length > 0 && el) {
      for (const child of item.children) {
        await this.createBlockElement(editMode, child, el, -1);
      }
    }
    return el;
  }

  /**
   * Clean the canvas by removing all elements
   * - and destroy directives
   * @returns void
   */
  private async cleanCanvas(pageIndex: number) {
    this.deSelectBlock();
    const page = this.pageInfo.pages[pageIndex];
    if (!page) return;
    await this.dynamicElementService.destroyBatch(page.bodyItems);
    await this.dynamicElementService.destroyBatch(page.headerItems);
    await this.dynamicElementService.destroyBatch(page.footerItems);
    if (this.pageBodyEl) {
      this.pageBodyEl.innerHTML = '';
    }
    if (LibConsts.viewMode == 'PrintPage') {
      this.pageHeaderEl!.innerHTML = '';
      this.pageFooterEl!.innerHTML = '';
    }
  }

  selectBlock(c: PageItem, ev?: PointerEvent) {
    // console.log('click on block', c.el);
    ev?.stopPropagation();
    ev?.preventDefault();
    if (this.activeEl() !== c) this.flushStyleChange();
    this.activeEl.set(c);
    this.onSelectBlock$.next({ ev: ev, item: c });
  }
  deSelectBlock() {
    this.activeEl.set(undefined);
    this.onSelectBlock$.next(undefined);
  }

  /**
   * return parent root bodyItems|headerItems|footerItems
   * @param item block
   * @returns parent root
   */
  findRootParentItem(item: PageItem) {
    const page = this.pageInfo.pages[this.currentPageIndex()];
    for (let p of page.headerItems) if (p.id == item.id) return page.headerItems;
    for (let p of page.bodyItems) if (p.id == item.id) return page.bodyItems;
    for (let p of page.footerItems) if (p.id == item.id) return page.footerItems;
    return undefined;
  }

  async removeBlock(item: PageItem) {
    if (!item || item.disableDelete) return;

    let parentChildren = item.parent?.children;
    if (!parentChildren) {
      parentChildren = this.findRootParentItem(item);
    }
    if (!item || !parentChildren) {
      throw new Error('Remove block failed: invalid parent item in list');
    }

    const index = parentChildren.findIndex((i: PageItem) => i.id === item.id);
    if (index !== -1 && item.el) {
      parentChildren.splice(index, 1);
      await this.dynamicElementService.destroy(item);
      await this.cls.removeBlockCss(item);
    }
    this.activeEl.set(undefined);
    this.updateChangeDetection({ item: item, parent: parentChildren, type: 'RemoveBlock' });

    this.history.saveDelete(item.parent?.id, index, item, `Delete block '${item.id}' from '${item.parent?.id}'`);
  }

  //---------------------------------- تغییر استایل بلاک (پنل تنظیمات) ----------------------------------
  // کاربر هنگام درگ اسلایدر/رنگ ده‌ها رویداد در ثانیه می‌فرستد. CSSOM همان لحظه به‌روز می‌شود (ارزان)،
  // ولی کارهای سنگین (deep clone برای history و اعلان تغییر به بیرون) فقط یک بار بعد از توقف انجام می‌شود.
  private styleBurst?: { item: PageItem; prevCss?: BlockCss; timer?: ReturnType<typeof setTimeout> };
  private static readonly STYLE_DEBOUNCE_MS = 400;

  /** قبل از اعمال تغییر صدا بزنید: اولین بار در هر burst، css قبلی را برای history نگه می‌دارد */
  beforeStyleChange(item: PageItem) {
    if (this.styleBurst?.item === item) return;
    this.flushStyleChange();
    this.styleBurst = { item, prevCss: LibConsts.enableHistory && item.css ? cloneDeep(item.css) : undefined };
  }

  /** بعد از اعمال تغییر صدا بزنید (debounce می‌شود) */
  notifyStyleChanged(item: PageItem) {
    if (this.styleBurst?.item !== item) this.styleBurst = { item };
    clearTimeout(this.styleBurst.timer);
    this.styleBurst.timer = setTimeout(() => this.flushStyleChange(), PageBuilderService.STYLE_DEBOUNCE_MS);
  }

  /** فوراً burst جاری را نهایی می‌کند (مثلاً هنگام عوض شدن بلاک انتخابی یا ذخیره) */
  flushStyleChange() {
    const burst = this.styleBurst;
    if (!burst) return;
    clearTimeout(burst.timer);
    this.styleBurst = undefined;

    const { item, prevCss } = burst;
    this.updateChangeDetection({ item, type: 'ChangeBlockProperties' });
    if (LibConsts.enableHistory) {
      // نمونه‌ی قبلی بلاک با css قبلی؛ history خودش deep-clone می‌کند
      const prev = Object.assign(Object.create(Object.getPrototypeOf(item)), item, { css: prevCss }) as PageItem;
      this.history.saveEdit(item.id, item, prev, `Change styles '${item.id}'`);
    }
  }

  writeItemValue(data: PageItem) {
    this.dynamicElementService.updateElementContent(data);
    this.updateChangeDetection({ item: data, type: 'ChangeBlockContent' });
  }
  changedProperties(item: PageItem) {
    if (item.el) {
      // item.style = item.el.style.cssText;
      // item.style = encodeURIComponent(item.el.style.cssText);
      if (item.content && item.content != item.el.textContent) {
        item.el.textContent = item.content;
        // item.el.textContent = this.dynamicDataService.replaceContentValue(item.content);
      }
    }
    this.cls.addBlockCss(item, false);
    this.updateChangeDetection({ item: item, type: 'ChangeBlockProperties' });

    // TODO: required previouws snapshot
    this.history.saveEdit(item.id, item, item, `Change properties '${item.id}': '${item.el?.style?.cssText}'`);
  }

  save() {
    this.flushStyleChange();
    this.isSaving = true;
    this.storageService
      .saveData()
      .then((result) => {
        Notify.success('Data saved successfully');
      })
      .finally(() => (this.isSaving = false));
  }

  async open() {
    return new Promise(async (resolve, reject) => {
      await this.reset();
      this.storageService
        .loadData()
        .then(async (data) => {
          this.pageInfo = PageBuilderDto.fromJSON({ config: data.config, pages: data.data });

          // console.log(this.pageInfo.pages.length);
          if (this.pageInfo.pages.length == 0) {
            this.addPage();
          } else {
            await this.changePage(1);
          }
          this.onUpdateBaseConfig$.next(this.pageInfo.config);
          resolve(true);
        })
        .catch((error) => {
          Notify.error(error);
          reject(error);
        });
    });
  }

  redo() {
    throw new Error('Method not implemented.');
  }
  undo() {
    throw new Error('Method not implemented.');
  }
  duplicateBlock(currentBlock: PageItem) {
    throw new Error('Method not implemented.');
  }
  async pasteBlock() {
    if (!this.activeEl() || !this.copyStorage || !this.activeEl()?.el) {
      return;
    }
    await this.addBlockToCurrentPage(this.copyStorage);
  }
  copyBlock(currentBlock: PageItem) {
    this.copyStorage = Object.assign({}, currentBlock);
    Notify.info('Block copied to memory');
  }

  async addBlockToCurrentPage(p: IPageItem) {
    try {
      let item = PageItem.fromJSON(p);
      item = this.clearIds(item);

      let activeBlock = this.activeEl();

      if (!this.currentPage) {
        await this.addPage();
      }
      if (activeBlock && activeBlock.canHaveChild) {
        item.parent = activeBlock;
        activeBlock.children.push(item);
        await this.createBlockElement(true, item, activeBlock?.el);
      } else {
        this.currentPage!.bodyItems.push(item);
        await this.createBlockElement(true, item);
      }
      this.selectBlock(item);
      Notify.success('Added successfully');
    } catch (error) {}
  }

  private clearIds(item: PageItem): PageItem {
    item.id = '';
    if (item.children) {
      for (let c of item.children) {
        this.clearIds(c);
      }
    }
    return item;
  }
}
