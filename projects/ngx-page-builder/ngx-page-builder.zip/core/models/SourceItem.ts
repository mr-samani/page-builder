import { Type } from '@angular/core';
import { CustomComponent } from './CustomComponent';
import { BlockCss } from '../contracts/IStyleSheetFile';
import type { SourceSettingField } from './SourceSettingField';
export class Directive {
  directive!: Type<any>;
  inputs?: Record<string, any> | undefined;
  outputs?: Record<string, Function> | undefined;
}

export interface ISourceOptions<CUSTOM_DATA = any> {
  events?: Record<string, (event: any) => boolean | void>;
  directives?: Directive[];

  /**
   * Html attributs
   * @example
   * {
   *   "class": "my-class",
   *   "id": "my-id"
   * }
   */
  attributes?: Record<string, any> | undefined;
  /**
   * Component inputs
   * - @Input()
   * @example
   * {
   *   "input1": "value1",
   *   "input2": "value2"
   * }
   */
  inputs?: Record<string, any> | undefined;
  /**
   * Component outputs
   * - @Output()
   * @example
   * {
   *   "output1": ($event)=>{ console.log($event); },
   * }
   */
  outputs?: Record<string, Function> | undefined;

  customData?: CUSTOM_DATA;
}

export class SourceItem {
  /** Stable registry key used to resolve the exact source schema for inserted blocks. */
  sourceId?: string;
  /**
   * HTML tag name.
   * @example 'div'
   */
  tag!: string; // 'div' | 'span' | 'p' | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'img' | 'input' = 'div';
  /**
   * can have child elements
   * like div, section,...
   * - هر ایتمی که children دارد باید canhavechild=true باشد چون drag-drop باید بتواند اندکس ها را درست حساب کند
   * @example true
   */
  canHaveChild?: boolean;
  /**
   *  Display title
   * @example 'My Chart'
   * */
  title?: string;
  /** Stable library category id used by the block library UI. */
  category?: string = undefined;
  /** Short explanation shown in the block library. */
  description?: string = undefined;
  /** Additional searchable terms for discovery. */
  keywords?: string[] = undefined;
  /** Declarative native-attribute settings rendered by the generic block inspector. */
  settings?: SourceSettingField[] = undefined;
  /** Child source definitions cloned when this block is inserted (e.g. a ready-to-edit list). */
  initialChildren?: SourceItem[] = undefined;
  /**
   * Block icon
   * @example <svg>...</svg>
   */
  icon: string = '';

  /**
   * Text content of html tags
   */
  content?: string;

  options?: ISourceOptions;

  /**
   * Disable movement of the source item
   * @example pagebreak cannot move to child items
   */
  disableMovement?: boolean = false;

  customComponent?: CustomComponent;

  css?: BlockCss;
  classList?: string[];
  isUserDefined?: boolean = false;
  constructor(data: SourceItem, isUserDefined?: boolean) {
    for (var property in data) {
      if (Object.hasOwn(this, property)) (<any>this)[property] = (<any>data)[property];
    }
    this.isUserDefined = isUserDefined == true;
    this.sourceId ??= this.customComponent?.componentKey
      ? `component:${this.customComponent.componentKey}`
      : `${this.isUserDefined ? 'custom' : 'source'}:${this.category ?? 'custom'}:${this.tag}:${this.title ?? ''}`;
  }
}
