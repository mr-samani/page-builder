# Landing page kit — ngx-page-builder

| فایل | کاربرد |
|---|---|
| `landing-page.en.json` | صفحه‌ی فرود شرکت طراحی سایت (انگلیسی، LTR) — مستقیم در صفحه‌ساز بارگذاری می‌شود |
| `landing-page.fa.json` | همان صفحه، فارسی و راست‌به‌چپ (RTL) |
| `AI-PROMPT.md` | پرامپت کامل برای هر هوش مصنوعی؛ بخش ۱۴ آخر فایل را با نیازهای خودتان پر کنید |
| `tools/pb-tools.mjs` | اعتبارسنج JSON + کامپایلر CSS + خروجی HTML (فقط Node، بدون نصب؛ با `npm i css-tree` مقدارهای CSS هم چک می‌شوند) |
| `tools/build_landing.py` | مولّد همین دو فایل JSON (برای تغییر متن/رنگ و ساخت دوباره) |
| `preview/*.html` | پیش‌نمایش مستقل بدون ادیتور (عکس‌ها پیش‌فرض خاکستری هستند) |
| `screens/*.png` | چند اسکرین‌شات از خروجی |

## استفاده از اعتبارسنج (پیشنهاد می‌شود)

```bash
node tools/pb-tools.mjs validate page.json        # خطاها و هشدارها
node tools/pb-tools.mjs html page.json out.html   # پیش‌نمایش در مرورگر
node tools/pb-tools.mjs css page.json             # CSS نهایی
```

حلقه‌ی کار با هوش مصنوعی: پرامپت → JSON → `validate` → اگر خطا داشت، خروجی ترمینال را همان‌طور برای هوش مصنوعی بفرستید تا اصلاح کند.

## نکته‌ها
- تمام صفحه داخل `bodyItems` است؛ `headerItems/footerItems` در حالت وب رندر نمی‌شوند.
- عکس‌ها عمداً `src` ندارند؛ بلوک‌های `img` با تصویر پیش‌فرض صفحه‌ساز نمایش داده می‌شوند. برای عوض کردن، روی بلوک عکس کلیک و فایل را انتخاب کنید.
- فونت‌ها (Inter / Vazirmatn) از Google Fonts با `@import` در استایل `landing` لود می‌شوند و بدون اینترنت فونت‌های سیستم جایگزین می‌شوند.
- رنگ‌ها و گرادیان برند در `cssVariables` هستند (`brand`, `brand-2`, `accent`, `ink`, `muted`, `line`, `surface`, `grad`, `radius`, `shadow-card`)؛ با تغییر آن‌ها کل صفحه عوض می‌شود.
