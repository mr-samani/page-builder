#!/usr/bin/env node
/**
 * pb-tools.mjs — ابزار مستقل (بدون وابستگی) برای JSON ورودی ngx-page-builder
 *
 *   node pb-tools.mjs validate page.json          → بررسی ساختار + قوانین CSS + هشدارهای ریسپانسیو
 *   node pb-tools.mjs css      page.json          → CSS نهایی (همان چیزی که preview می‌سازد)
 *   node pb-tools.mjs html     page.json out.html → HTML مستقل برای پیش‌نمایش بدون ادیتور
 *
 * قوانین از روی کد واقعی core/utiles/block-css.ts و dynamic-element.service.ts پیاده‌سازی شده‌اند.
 * اگر `css-tree` نصب باشد (npm i css-tree) مقدارهای CSS هم اعتبارسنجی می‌شوند.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

//==================================================================================
// Constants (mirrors the library)
//==================================================================================

export const BREAKPOINTS = [
  { key: 'sm', minWidth: 576 },
  { key: 'md', minWidth: 768 },
  { key: 'lg', minWidth: 992 },
  { key: 'xl', minWidth: 1200 }, // base: بدون media query
  { key: 'xxl', minWidth: 1400 },
];
export const BASE_KEY = 'xl';
export const PSEUDO_ORDER = ['visited', 'hover', 'focus', 'focus-visible', 'active', 'checked', 'disabled'];
const EPS = 0.02;
const SAFE_PROP = /^(--[A-Za-z0-9_\u00A0-\uFFFF-]+|[a-z-]+)$/;
const VOID_TAGS = new Set(['img', 'input', 'br', 'hr', 'meta', 'link', 'source', 'wbr', 'area', 'col', 'embed', 'track']);
const FORBIDDEN_TAGS = new Set(['script', 'style', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'html', 'head', 'body']);
const SVG_TAGS = new Set(['svg', 'path', 'circle', 'rect', 'g', 'line', 'polyline', 'polygon', 'ellipse', 'defs', 'use', 'text']);

//==================================================================================
// Declarations
//==================================================================================

/** مثل parseDecls کتابخانه، ولی بخش‌های خراب (بدون «:») را هم گزارش می‌دهد */
export function splitDecls(text) {
  const parts = [];
  let start = 0, depth = 0, quote = '';
  const flush = (end) => {
    const seg = text.slice(start, end);
    if (seg.trim()) parts.push(seg);
  };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) { if (ch === '\\') i++; else if (ch === quote) quote = ''; continue; }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '(') depth++;
    else if (ch === ')' && depth > 0) depth--;
    else if (ch === ';' && depth === 0) { flush(i); start = i + 1; }
  }
  flush(text.length);
  const decls = [], bad = [];
  for (const seg of parts) {
    const i = seg.indexOf(':');
    const prop = i > 0 ? seg.slice(0, i).trim() : '';
    const value = i > 0 ? seg.slice(i + 1).trim() : '';
    if (!prop || !value) bad.push(seg.trim());
    else {
      if (!prop.startsWith('--') && /[A-Z]/.test(prop)) bad.push(`${prop}:${value.slice(0, 30)} (property names must be lowercase kebab-case, e.g. background-color — camelCase is silently turned into an invalid name)`);
      decls.push([prop.startsWith('--') ? prop : prop.toLowerCase(), value]);
    }
  }
  return { decls, bad };
}

export function isSafeDecl(prop, value) {
  if (!SAFE_PROP.test(prop)) return false;
  let quote = '';
  for (let i = 0; i < value.length; i++) {
    const ch = value[i];
    if (quote) { if (ch === '\\') i++; else if (ch === quote) quote = ''; continue; }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '{' || ch === '}' || ch === '<' || ch === '>') return false;
    else if (ch === '/' && value[i + 1] === '*') return false;
  }
  return !quote;
}

export function sanitizeDecls(text) {
  const map = new Map();
  for (const [k, v] of splitDecls(text ?? '').decls) if (isSafeDecl(k, v)) map.set(k, v);
  let out = '';
  for (const [k, v] of map) out += `${k}:${v};`;
  return out;
}

//==================================================================================
// Breakpoints → media
//==================================================================================

export function mediaCondition(key) {
  if (key === BASE_KEY) return null;
  const list = [...BREAKPOINTS].sort((a, b) => a.minWidth - b.minWidth);
  const base = list.find((b) => b.key === BASE_KEY);
  const target = list.find((b) => b.key === key);
  if (!target) return null;
  if (target.minWidth > base.minWidth) return `(min-width:${target.minWidth}px)`;
  const larger = list.find((b) => b.minWidth > target.minWidth);
  return larger ? `(max-width:${+(larger.minWidth - EPS).toFixed(2)}px)` : null;
}
export function mediaRank(key) {
  const base = BREAKPOINTS.find((b) => b.key === BASE_KEY);
  const t = BREAKPOINTS.find((b) => b.key === key);
  if (!t) return Number.MAX_SAFE_INTEGER;
  return t.minWidth < base.minWidth ? -t.minWidth : t.minWidth;
}

//==================================================================================
// Compile
//==================================================================================

export function blockClass(node) {
  return node.classList?.find((c) => c.startsWith('blk-')) ?? `blk-${node.id ?? ''}`;
}

function emitChunk(sel, chunk, into) {
  if (!chunk) return;
  const base = sanitizeDecls(chunk.base);
  if (base) into.push(`${sel}{${base}}`);
  for (const s of PSEUDO_ORDER) {
    const t = sanitizeDecls(chunk.states?.[s]);
    if (t) into.push(`${sel}:${s}{${t}}`);
  }
}

export function compileBlocksCss(roots) {
  const root = [];
  const media = new Map();
  const walk = (n) => {
    const css = typeof n.css === 'string' ? { base: n.css } : n.css;
    if (css) {
      const sel = '.' + blockClass(n).replace(/[^A-Za-z0-9_-]/g, '');
      emitChunk(sel, css, root);
      for (const k of Object.keys(css.breakpoints ?? {})) {
        if (k === BASE_KEY || !BREAKPOINTS.some((b) => b.key === k)) continue;
        if (!media.has(k)) media.set(k, []);
        emitChunk(sel, css.breakpoints[k], media.get(k));
      }
    }
    (n.children ?? []).forEach(walk);
    if (n.template) walk(n.template);
  };
  roots.forEach(walk);
  let out = root.join('');
  for (const k of [...media.keys()].sort((a, b) => mediaRank(a) - mediaRank(b))) {
    const cond = mediaCondition(k);
    if (cond && media.get(k).length) out += `@media ${cond}{${media.get(k).join('')}}`;
  }
  return out;
}

export function compileCssVariables(vars) {
  let body = '';
  for (const v of vars ?? []) {
    if (!v?.name || !/^[A-Za-z0-9_-]+$/.test(v.name)) continue;
    if (!isSafeDecl(`--${v.name}`, String(v.value ?? ''))) continue;
    body += `--${v.name}:${v.value};`;
  }
  return body ? `:root{${body}}` : '';
}

export function compileAllCss(doc) {
  const roots = [];
  for (const p of doc.data ?? []) roots.push(...(p.headerItems ?? []), ...(p.bodyItems ?? []), ...(p.footerItems ?? []));
  return compileCssVariables(doc.cssVariables) + compileBlocksCss(roots);
}

//==================================================================================
// Static HTML export (mirrors DynamicElementService.createBlock in WebPage mode)
//==================================================================================

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

export function itemToHtml(item, defaultImage) {
  const tag = item.tag || 'div';
  const attrs = { ...(item.options?.attributes ?? {}) };
  if (tag === 'img' && !('src' in attrs)) attrs.src = defaultImage;
  attrs['data-id'] = item.id;
  const classes = item.classList?.length ? ` class="${esc(item.classList.join(' '))}"` : '';
  const a = Object.entries(attrs).map(([k, v]) => ` ${k}="${esc(v)}"`).join('');
  if (VOID_TAGS.has(tag)) return `<${tag}${a}${classes}>`;
  const inner = (item.content ?? '') + (item.children ?? []).map((c) => itemToHtml(c, defaultImage)).join('');
  return `<${tag}${a}${classes}>${inner}</${tag}>`;
}

export function toHtml(doc, { defaultImage = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600"><rect width="100%" height="100%" fill="#e8eaf2"/><path d="M300 380l70-90 60 70 40-50 80 70z" fill="#c3c8da"/><circle cx="330" cy="250" r="26" fill="#c3c8da"/></svg>') } = {}) {
  const cfg = doc.config ?? {};
  const styles = (doc.styles ?? []).map((s) => `<style id="${esc(s.name)}">${s.data}</style>`).join('\n');
  const body = (doc.data ?? [])
    .map((p) => (p.bodyItems ?? []).map((i) => itemToHtml(i, defaultImage)).join(''))
    .join('');
  return `<!doctype html>
<html lang="${cfg.direction === 'rtl' ? 'fa' : 'en'}" dir="${cfg.direction ?? 'ltr'}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(cfg.title ?? '')}</title>
${styles}
<style id="NgxPageBuilderBlockStyles">${compileAllCss(doc)}</style>
</head>
<body style="margin:0">
<div class="ngx-page-builder web-page-view" dir="${cfg.direction ?? 'ltr'}">${body}</div>
</body>
</html>`;
}

//==================================================================================
// Validate
//==================================================================================

const STATES = new Set(PSEUDO_ORDER);
const BP_KEYS = new Set(['sm', 'md', 'lg', 'xxl']);

export async function validate(doc) {
  const errors = [];
  const warnings = [];
  const E = (path, msg) => errors.push(`${path}: ${msg}`);
  const W = (path, msg) => warnings.push(`${path}: ${msg}`);

  let csstree = null;
  try { csstree = await import('css-tree'); } catch { /* optional */ }

  // ---- top level
  if (!doc || typeof doc !== 'object') return { errors: ['root: must be an object'], warnings, stats: {} };
  const cfg = doc.config;
  if (!cfg || typeof cfg !== 'object') E('config', 'missing');
  else {
    if (!['A4', 'A5', 'Letter'].includes(cfg.size)) E('config.size', 'must be "A4" | "A5" | "Letter"');
    if (!['Portrait', 'Landscape'].includes(cfg.orientation)) E('config.orientation', 'must be "Portrait" | "Landscape"');
    if (!['ltr', 'rtl'].includes(cfg.direction)) E('config.direction', 'must be "ltr" | "rtl"');
    if (typeof cfg.title !== 'string') E('config.title', 'must be a string');
  }
  if (!Array.isArray(doc.data) || doc.data.length === 0) E('data', 'must be a non-empty array of pages');
  if (!Array.isArray(doc.styles)) E('styles', 'must be an array (may be empty)');
  if (!Array.isArray(doc.cssVariables)) E('cssVariables', 'must be an array (may be empty)');

  // ---- css variables
  const varNames = new Set();
  (doc.cssVariables ?? []).forEach((v, i) => {
    const p = `cssVariables[${i}]`;
    if (!['text', 'color', 'gradient', 'number'].includes(v?.type)) E(p, 'type must be text | color | gradient | number');
    if (typeof v?.name !== 'string' || !/^[A-Za-z0-9_][A-Za-z0-9_-]*$/.test(v.name)) E(p, 'name must match [A-Za-z0-9_-]+ and must NOT start with "-" or "--" (the builder adds the "--" itself)');
    else if (varNames.has(v.name)) E(p, `duplicate variable "${v.name}"`);
    else varNames.add(v.name);
    if (typeof v?.value !== 'string' || !isSafeDecl(`--${v?.name ?? 'x'}`, v.value)) E(p, 'value is empty or unsafe');
  });

  // ---- styles
  const styleNames = new Set();
  (doc.styles ?? []).forEach((s, i) => {
    const p = `styles[${i}]`;
    if (typeof s?.name !== 'string' || !/^[A-Za-z][A-Za-z0-9_-]*$/.test(s.name)) E(p, 'name must be a valid CSS identifier (letters/digits/-/_, starting with a letter) because it becomes <style id>');
    else if (styleNames.has(s.name)) E(p, `duplicate style name "${s.name}"`);
    else styleNames.add(s.name);
    if (typeof s?.data !== 'string') E(p, 'data must be a CSS string');
    else {
      if (/<\/style/i.test(s.data)) E(p, 'must not contain "</style"');
      if (csstree) {
        csstree.parse(s.data, { onParseError: (err) => W(p, `CSS parse: ${err.message} (line ${err.line})`) });
      }
    }
  });

  // ---- pages / items
  const ids = new Set();
  const stats = { items: 0, withCss: 0, bpUsed: new Set(), stateUsed: new Set(), pages: 0 };
  const usedVars = new Set();
  const trackVars = (text) => {
    for (const m of String(text).matchAll(/var\(\s*--([A-Za-z0-9_-]+)\s*(,)?/g)) usedVars.add(m[1] + (m[2] ? '|fb' : ''));
  };

  const checkChunk = (path, chunk, isBp) => {
    if (!chunk || typeof chunk !== 'object') return E(path, 'must be an object');
    for (const k of Object.keys(chunk)) if (k !== 'base' && k !== 'states' && !(isBp && false)) E(`${path}.${k}`, 'unknown key (allowed: base, states' + (isBp ? '' : ', breakpoints') + ')');
    const check = (p, text) => {
      if (typeof text !== 'string') return E(p, 'must be a string of CSS declarations like "color:red;"');
      if (/[{}]/.test(text.replace(/(["'])(?:\\.|(?!\1).)*\1/g, ''))) E(p, 'contains "{" or "}" — write declarations only, never a full rule');
      if (/@media|@keyframes|::?[a-z-]+\s*\{/.test(text)) E(p, 'contains an at-rule or selector — not allowed in block css');
      const { decls, bad } = splitDecls(text);
      for (const b of bad) E(p, `malformed declaration "${b.slice(0, 60)}" (it would be silently dropped)`);
      const seen = new Set();
      for (const [prop, val] of decls) {
        if (!isSafeDecl(prop, val)) E(p, `unsafe/rejected declaration "${prop}:${val.slice(0, 40)}" (property must be lowercase kebab-case; value must not contain { } < > or comments)`);
        if (seen.has(prop)) W(p, `property "${prop}" is declared twice (the later one wins)`);
        seen.add(prop);
        trackVars(val);
        if (csstree && SAFE_PROP.test(prop) && !prop.startsWith('--')) {
          try {
            const ast = csstree.parse(val, { context: 'value' });
            const res = csstree.lexer.matchProperty(prop, ast);
            if (res.error && !/var\(/.test(val)) W(p, `"${prop}:${val.slice(0, 50)}" — ${String(res.error.message).split('\n')[0]}`);
          } catch { /* ignore */ }
        }
      }
      if (/(^|;)\s*[a-z-]+\s*:[^;]*!important/.test(text)) W(p, '!important makes responsive overrides impossible — avoid it');
    };
    if (chunk.base !== undefined) check(`${path}.base`, chunk.base);
    if (chunk.states !== undefined) {
      if (typeof chunk.states !== 'object') E(`${path}.states`, 'must be an object');
      else for (const [s, t] of Object.entries(chunk.states)) {
        if (!STATES.has(s)) E(`${path}.states.${s}`, `unsupported state (allowed: ${[...STATES].join(', ')})`);
        else stats.stateUsed.add(s);
        check(`${path}.states.${s}`, t);
      }
    }
  };

  const walk = (item, path) => {
    stats.items++;
    if (!item || typeof item !== 'object') return E(path, 'must be an object');
    const id = item.id;
    if (typeof id !== 'string' || !/^[A-Za-z0-9_-]+$/.test(id)) E(path, `id "${id}" must match [A-Za-z0-9_-]+`);
    else if (ids.has(id)) E(path, `duplicate id "${id}" (ids must be unique across the whole document)`);
    else ids.add(id);

    const tag = item.tag;
    if (typeof tag !== 'string' || !/^[a-z][a-z0-9-]*$/.test(tag)) E(path, `tag "${tag}" must be a lowercase HTML tag name`);
    else {
      if (FORBIDDEN_TAGS.has(tag)) E(path, `tag "${tag}" is not allowed`);
      if (SVG_TAGS.has(tag)) E(path, `tag "${tag}" is an SVG element — createElement() makes it an inert HTMLUnknownElement. Put the whole <svg>…</svg> markup in the "content" of a span/div instead`);
    }
    if (typeof item.canHaveChild !== 'boolean') E(path, '"canHaveChild" must be true or false');
    const kids = item.children;
    if (!Array.isArray(kids)) E(path, '"children" must be an array (use [] when empty)');
    if (Array.isArray(kids) && kids.length && item.canHaveChild !== true) E(path, 'has children but canHaveChild is not true');
    if (VOID_TAGS.has(tag)) {
      if (kids?.length) E(path, `<${tag}> is a void element and cannot have children`);
      if (item.content) E(path, `<${tag}> is a void element and cannot have content`);
    }
    if (item.content !== undefined && typeof item.content !== 'string') E(path, '"content" must be a string (innerHTML)');
    if (item.content && kids?.length) W(path, 'has both content and children — content is rendered first, then children are appended after it');
    if (item.content && /<script|on[a-z]+\s*=|javascript:/i.test(item.content)) E(path, 'content contains script/event-handler markup');

    const attrs = item.options?.attributes;
    if (item.options !== undefined && (typeof item.options !== 'object' || item.options === null)) E(path, '"options" must be an object');
    if (attrs !== undefined) {
      if (typeof attrs !== 'object' || attrs === null) E(path, 'options.attributes must be an object');
      else for (const [k, v] of Object.entries(attrs)) {
        if (typeof v !== 'string') E(`${path}.options.attributes.${k}`, 'attribute values must be strings');
        if (/^on/i.test(k)) E(`${path}.options.attributes.${k}`, 'event-handler attributes are not allowed');
        if (k === 'class') W(`${path}.options.attributes.class`, 'put classes in "classList", not in attributes.class');
        if (k === 'style') W(`${path}.options.attributes.style`, 'use "css" instead of an inline style attribute (it cannot be responsive)');
        if (/^(href|src|action)$/i.test(k) && /^\s*javascript:/i.test(String(v))) E(`${path}.options.attributes.${k}`, 'javascript: URLs are not allowed');
      }
    }
    if (tag === 'img' && !attrs?.alt) W(path, 'img without alt text');
    if (tag === 'a' && !attrs?.href) W(path, 'link without href');

    // classList + blk class
    const cl = item.classList;
    if (!Array.isArray(cl)) E(path, '"classList" must be an array');
    else {
      for (const c of cl) if (typeof c !== 'string' || /\s/.test(c) || !c) E(path, `class "${c}" must be one non-empty token without spaces`);
      const blk = cl.filter((c) => typeof c === 'string' && c.startsWith('blk-'));
      if (blk.length > 1) E(path, 'more than one blk- class');
      if (blk.length === 1 && blk[0] !== `blk-${id}`) E(path, `class "${blk[0]}" must be exactly "blk-${id}"`);
      if (item.css && blk.length === 0) E(path, `has "css" but classList lacks "blk-${id}" — the styles would never apply`);
    }

    // css
    if (item.css !== undefined) {
      stats.withCss++;
      const css = item.css;
      if (typeof css !== 'object' || css === null || Array.isArray(css)) E(`${path}.css`, 'must be an object {base, states, breakpoints}');
      else {
        for (const k of Object.keys(css)) if (!['base', 'states', 'breakpoints'].includes(k)) E(`${path}.css.${k}`, 'unknown key (allowed: base, states, breakpoints)');
        checkChunk(`${path}.css`, { base: css.base, states: css.states }, false);
        for (const [bp, chunk] of Object.entries(css.breakpoints ?? {})) {
          if (bp === 'xl') E(`${path}.css.breakpoints.xl`, '"xl" is the base breakpoint — put its styles in css.base / css.states, never under breakpoints');
          else if (!BP_KEYS.has(bp)) E(`${path}.css.breakpoints.${bp}`, 'unknown breakpoint (allowed: xxl, lg, md, sm)');
          else stats.bpUsed.add(bp);
          checkChunk(`${path}.css.breakpoints.${bp}`, chunk, true);
        }
        responsiveLint(path, tag, css, kids?.length ?? 0);
      }
    }
    (kids ?? []).forEach((c, i) => walk(c, `${path}.children[${i}]`));
    if (item.template) walk(item.template, `${path}.template`);
  };

  const get = (text, prop) => {
    if (typeof text !== 'string') return undefined;
    let v;
    for (const [k, val] of splitDecls(text).decls) if (k === prop) v = val;
    return v;
  };
  function responsiveLint(path, tag, css, kidCount = 0) {
    const base = css.base;
    const small = (prop) => ['sm', 'md', 'lg'].some((k) => get(css.breakpoints?.[k]?.base, prop) !== undefined);
    const cols = get(base, 'grid-template-columns');
    if (cols && !/auto-fit|auto-fill/.test(cols) && !small('grid-template-columns')) {
      const rep = /^repeat\(\s*(\d+)/.exec(cols.trim());
      const n = rep ? parseInt(rep[1], 10) : cols.trim().split(/\s+(?![^(]*\))/).filter(Boolean).length;
      if (n >= 2) W(path, `${n}-column grid (${cols.slice(0, 40)}) has no md/sm override — it will not collapse on phones`);
    }
    const w = get(base, 'width');
    const px = w && /^(\d+(?:\.\d+)?)px$/.exec(w);
    if (px && +px[1] > 420 && !small('width') && get(base, 'max-width') === undefined) W(path, `fixed width ${w} with no max-width/mobile override — likely overflows on phones`);
    const fs = get(base, 'font-size');
    const fpx = fs && /^(\d+(?:\.\d+)?)px$/.exec(fs);
    if (fpx && +fpx[1] >= 40 && !small('font-size')) W(path, `large font-size ${fs} has no md/sm override`);
    if (kidCount >= 3 && get(base, 'display') === 'flex' && /row/.test(get(base, 'flex-direction') ?? 'row') && get(base, 'flex-wrap') === undefined && !small('flex-direction') && !small('flex-wrap') && !small('display') && !/column/.test(get(base, 'flex-direction') ?? '')) {
      // only a soft hint: a flex row without wrap and without mobile rule can overflow
      W(path, 'flex row without flex-wrap and without a mobile override — check it does not overflow on phones');
    }
  }

  (doc.data ?? []).forEach((page, pi) => {
    stats.pages++;
    const p = `data[${pi}]`;
    for (const k of ['headerItems', 'bodyItems', 'footerItems']) if (!Array.isArray(page?.[k])) E(`${p}.${k}`, 'must be an array (use [] when empty)');
    if (typeof page?.order !== 'number') E(`${p}.order`, 'must be a number');
    if (!page?.config || typeof page.config !== 'object') E(`${p}.config`, 'must be an object {title, description}');
    if ((page?.headerItems?.length || page?.footerItems?.length)) W(p, 'headerItems/footerItems are NOT rendered in WebPage view mode — keep a landing page entirely in bodyItems');
    (page?.bodyItems ?? []).forEach((it, i) => walk(it, `${p}.bodyItems[${i}]`));
    (page?.headerItems ?? []).forEach((it, i) => walk(it, `${p}.headerItems[${i}]`));
    (page?.footerItems ?? []).forEach((it, i) => walk(it, `${p}.footerItems[${i}]`));
  });

  // css text in styles[] may also use variables
  (doc.styles ?? []).forEach((s) => typeof s?.data === 'string' && trackVars(s.data));
  for (const u of usedVars) {
    const [name, fb] = u.split('|');
    if (!varNames.has(name) && !fb) W('cssVariables', `var(--${name}) is used but not defined in cssVariables (and has no fallback)`);
  }
  if (stats.items > 5 && stats.bpUsed.size === 0) W('css', 'no breakpoint overrides at all — the page will not be responsive');
  for (const k of ['md', 'sm']) if (stats.items > 20 && !stats.bpUsed.has(k)) W('css', `breakpoint "${k}" is never used`);

  return {
    errors,
    warnings,
    stats: { ...stats, bpUsed: [...stats.bpUsed], stateUsed: [...stats.stateUsed] },
  };
}

//==================================================================================
// CLI
//==================================================================================

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [cmd, file, out] = process.argv.slice(2);
  if (!cmd || !file) {
    console.log('usage: node pb-tools.mjs <validate|css|html> page.json [out.html]');
    process.exit(2);
  }
  let doc;
  try {
    doc = JSON.parse(readFileSync(file, 'utf8'));
  } catch (e) {
    console.error('✖ Invalid JSON:', e.message);
    process.exit(1);
  }
  if (cmd === 'css') console.log(compileAllCss(doc));
  else if (cmd === 'html') {
    writeFileSync(out ?? 'preview.html', toHtml(doc));
    console.log('wrote', out ?? 'preview.html');
  } else {
    const r = await validate(doc);
    for (const e of r.errors) console.log('✖ ERROR  ', e);
    for (const w of r.warnings) console.log('⚠ WARNING', w);
    console.log(`\n${r.errors.length ? '✖' : '✔'} ${r.stats.items} items · ${r.stats.withCss} styled · breakpoints used: ${r.stats.bpUsed.join(', ') || 'none'} · states used: ${r.stats.stateUsed.join(', ') || 'none'}`);
    console.log(`  ${r.errors.length} error(s), ${r.warnings.length} warning(s)`);
    process.exit(r.errors.length ? 1 : 0);
  }
}
